def search4letters(phrase: str, letters: str = 'aeiouAEIOU') -> set:
    """Return a set of 'letters' found in 'phrase'."""
    return set(letters).intersection(set(phrase))
