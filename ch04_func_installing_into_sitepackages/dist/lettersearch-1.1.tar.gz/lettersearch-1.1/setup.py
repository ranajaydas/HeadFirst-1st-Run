from setuptools import setup

setup(
    name='lettersearch',
    version='1.1',
    description='Letter Search Tool',
    author='Ranajay Das',
    author_email='ranajay@outlook.com',
    url='ranajayontheroad.com',
    py_modules=['ch04_func_lettersearch'],
)
